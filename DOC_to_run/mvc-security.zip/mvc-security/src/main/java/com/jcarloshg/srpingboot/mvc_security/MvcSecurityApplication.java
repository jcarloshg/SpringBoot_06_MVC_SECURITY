package com.jcarloshg.srpingboot.mvc_security;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MvcSecurityApplication {

	public static void main(String[] args) {
		SpringApplication.run(MvcSecurityApplication.class, args);
	}

}
